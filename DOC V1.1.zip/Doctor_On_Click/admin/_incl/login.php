<?php
$error = "";
session_start();
include 'DB.php';
if(isset($_SESSION['admin_data']) && !empty($_SESSION['admin_data'])){
    header("Location:../dashboard.php");
    
}
if(empty($_POST['email']))
 {
     echo "Email is Empty";
 }
 if(empty($_POST['password']))
 {
     echo"Password is Empty";
 }
 
if(isset($_POST['email']) && isset($_POST['password'])){
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);
    //echo $password;exit;
    $login_query = "SELECT * FROM `admin` WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $login_query);
 $num_rows = mysqli_num_rows($result);
 
 if(!$result|| $num_rows<=0)
 {
     echo"Error user and Password Does Not Match please GO back and Try Again";
 }
 if ($num_rows == 1)
    {
         $_SESSION['admin_data'] = mysqli_fetch_assoc($result);
        header("Location:../dashboard.php");
       
    }
   else
    {
        $error = '<script>alert("Invalid Username or Password");</script>';
        echo"$error";
       
    }  
}

 
?>



