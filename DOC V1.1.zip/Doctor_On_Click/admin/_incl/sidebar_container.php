  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="dashboard.php" class="brand-link">
      <img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Doctor's on Click</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <?php
			echo"<img src='../user_pics/".$_SESSION['admin_data']['id'].".jpg' style='height:50px;width:50px' class='img-circle elevation-2' alt='User Image'>";?>
        </div>
        <div class="info">
                <a href="#" class="d-block"><?= $_SESSION['admin_data']['name']?></a>
          
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            
              <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-user"></i>
              <p>
              Doctor's Data 
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
                  <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="doctor_submit_form.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Doctor Submition Form</p>
                </a>
                  <a href="doctor_data_table.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Doctor Data Table</p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-header">Actions</li>
          <li class="nav-item">
            <a href="_incl/logout.php" class="nav-link">
              <i class="nav-icon fa fa-circle-o text-danger"></i>
              <p class="text">Logout</p>
            </a>
          </li>
<!--          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-circle-o text-warning"></i>
              <p>Warning</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-circle-o text-info"></i>
              <p>Informational</p>
            </a>
          </li>-->
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
