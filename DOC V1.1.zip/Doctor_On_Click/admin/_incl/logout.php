<?php
session_start();
unset($_SESSION['admin_data']);
header("location:../login.php");