<?php
$host="localhost";
$user="root";
$pass="";
$DB="doctor";
$conn= new mysqli($host,$user,$pass,$DB);
/*
if($conn->connect_error)
{
    echo'Connection Falied';
}
else
{
    echo'Connected';
} */