<?php
include 'DB.php';
include 'forgot_password.php';
$pass=md5($_POST['pass']);
$check_pass=md5($_POST['pass1']);
if($pass==$check_pass)
{
$sql="UPDATE `admin` SET `password`='$pass' WHERE email='$email'";
 $result= mysqli_query($conn, $sql);
         if($result)
         {
             echo"Password is reset";
         }
// header("Location:login.php");
}
else{
    echo "Sorry";
}