<?php
include 'DB.php';
$id=$_REQUEST['id'];
$sql="DELETE FROM `doctor_data` WHERE id=$id";
mysqli_query($conn,$sql);
header("Location:../doctor_data_table.php");