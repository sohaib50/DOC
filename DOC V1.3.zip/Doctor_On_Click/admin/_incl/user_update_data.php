<?php
include 'DB.php';

$id=$_REQUEST['id'];

$name=$_POST['name'];
$email=$_POST['email'];
$dob=$_POST['dob'];


$sql="UPDATE `admin` SET `name`='$name',"
        . "`email`='$email',"
        . "`dob`='$dob', WHERE id='$id'";

mysqli_query($conn, $sql);
//Picture Savaing Code
//$sql = "SELECT MAX(id) as ID FROM admin";
//$ID = mysqli_query($conn, $sql);
//$ID = mysqli_fetch_assoc($ID);
$ID =$id;
$path="../../admins_pics/";
$file_name = $_FILES ['image']['tmp_name'];
move_uploaded_file ($file_name, $path .$ID. ".jpg");
header("Location:../user_profile.php");    