<?php include '_incl/check.php'; ?>
<?php include '_incl/head.php'; ?>
<?php include '_incl/navbar.php'; ?>
<?php include '_incl/sidebar_container.php'; ?>
<?php include '_incl/wrapper.php'; ?>
<div class="container">
<div class="col-md-10">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Doctor Submission Form </h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" method="POST" action="_incl/doctor_shubmission.php" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="form-group">
                    <label for="exampleInputName">Doctor Name</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="doc_name" placeholder="Doc Name">
                  </div>
                    <div class="form-group">
                    <label for="exampleInputEmail1">Doctor Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" name="doc_email" placeholder="Enter email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Doctor Type</label>
                    <select class="form-control" name="type">
                        <option>Select Categories</option>
                        <option value="Child">Child Specialist</option>
                        <option value="Cardiologist">Cardiologists </option>
                        <option value="Dentist">Dentist</option>
                        <option value="Eye">Eye Specialist</option>
                    </select>
                  </div>
                    <div class="form-group">
                    <label for="exampleInputEmail1">Doctor Address</label>
                    <input type="text" class="form-control" name="doc_address"  id="exampleInputEmail1" placeholder="Enter Address">
                  </div>
                    <div class="form-group">
                    <label for="exampleInputEmail1">Doctor Phone Number</label>
                    <input type="text" class="form-control" name="doc_num" id="exampleInputEmail1" placeholder="Enter Phone #">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">File input</label>
                    <div class="input-group">
                      <div class="custom-file">
                          <input type="file" class="custom-file-input" name="image" id="exampleInputFile">
                        <label class="custom-file-label" for="exampleInputFile">Doctor Picture</label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text" id="">Upload</span>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
</div>
			<?php include '_incl/footer.php';