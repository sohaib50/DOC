<?php include '_incl/check.php'; ?>
<?php include '_incl/head.php'; ?>
<?php include '_incl/navbar.php'; ?>
<?php include '_incl/sidebar_container.php'; ?>
<?php include '_incl/wrapper.php'; ?>
<?php include '_incl/footer.php'; 
